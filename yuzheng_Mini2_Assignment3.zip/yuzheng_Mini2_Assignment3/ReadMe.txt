# Mini-2 Assignment 3
Name : Yu Zheng
Andrew ID : yuzheng

# Platform(I used):
	Operating System: OS X El Capitan 10.11
	Java Version: JavaSE-1.7
	Android API 21
	Android Stdio 1.1.0

This assignment 2 Android Apps for Assignment3

(Package)
	PartA: All file for Mini-2 Assignment 3 Part A
	PartB: All file for Mini-2 Assignment 3 Part B