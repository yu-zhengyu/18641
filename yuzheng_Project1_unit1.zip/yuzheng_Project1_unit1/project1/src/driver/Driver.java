package driver;
import model.Automotive;
import util.FileIO;

/**
 * @version  1.0
 * @author YuZheng
 * @Date 9/14/2015
 * 
 * This class is a test file, would read the file to do the configuration of Automotive
 * And print it out. 
 * And then, Serialize the object, deseriablize the object, print it out again.
 */ 

public class Driver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Build Automobile Object from a file.
		FileIO io = new FileIO();
		Automotive FordZTW = null;
		FordZTW = io.buildAutoObject("FordZTW.txt", FordZTW);
		//Print attributes before serialization
		FordZTW.printBasicInfomation();
		FordZTW.printoption();
		//Serialize the object
		System.out.println("----------------------------------");
		System.out.println("Serialize the object and Deserialize and then read it");
		io.serializeAuto(FordZTW);
		//Deserialize the object and read it into memory.
		Automotive newFordZTW = io.DeserializeAuto("auto.ser"); //Print new attributes.
		System.out.println("----------------------------------");
		newFordZTW.printBasicInfomation();
		newFordZTW.printoption();
	}

}
