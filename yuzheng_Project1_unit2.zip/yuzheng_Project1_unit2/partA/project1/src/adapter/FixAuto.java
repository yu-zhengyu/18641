package adapter;

/**
 * @version  1.0
 * @author YuZheng
 * @Date 9/20/2015
 * 
 * This is a interface, just support some fix function to handle the exception.
 */ 

public interface FixAuto {
	public void fix(int errno);
}
