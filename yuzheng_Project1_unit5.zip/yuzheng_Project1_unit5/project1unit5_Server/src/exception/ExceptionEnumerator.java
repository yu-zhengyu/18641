package exception;

/**
 * @version  1.0
 * @author YuZheng
 * @Date 9/20/2015
 * 
 * This is a enum, just list some exception.
 */ 

public enum ExceptionEnumerator {
	fileNotFound,
	noBasePrice,
	noOptionSetNmae,
	noOptionName,
	noOptionPrice
}
